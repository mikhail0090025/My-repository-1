﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shadows : MonoBehaviour
{
	public GameObject j;
	public GameObject h;
	public bool bol = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    	if(Input.GetKeyDown(KeyCode.E)){
            if(bol){
            	bol = false;
            }
            else{
            	bol = true;
            }
    	}
    	if(bol){
            j.SetActive(true);
            h.SetActive(false);
    	}
    	else{
            j.SetActive(false);
            h.SetActive(true);
    	}
        
    }
}
